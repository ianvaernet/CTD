package com.company;

public enum EstadoArma {
    Nueva,
    EnMantenimiento,
    EnUso
}
